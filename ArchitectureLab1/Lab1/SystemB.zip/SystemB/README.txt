change the working directory to SystemA/SystemB
type the following command:
javac Plumber.java
java Plumber