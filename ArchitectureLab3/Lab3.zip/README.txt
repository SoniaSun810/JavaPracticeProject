To run the assignment, git clone the project first:

https://github.com/jwlin/android-retrofit-tutorial

Import the cloned project with Android Studio, and replace "YOUR_API_KEY" in MainActivity.java with this API Key: 5f7cb29d489bbbb86ca6e6d90f422eb2

Run the app with an Android 8.1 emulator (API Level 27) or higher.